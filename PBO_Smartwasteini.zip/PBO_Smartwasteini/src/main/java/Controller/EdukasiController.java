/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Koneksi.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Edukasi;

/**
 *
 * @author lulutt
 */
public class EdukasiController {
    private Connection conn;

    public EdukasiController() {
        conn = Connector.getConnection();
    }

    public boolean tambahEdukasi(Edukasi edukasi) {

        try {

            String query =
                "INSERT INTO edukasi " + "(edukasi) " + "VALUES (?,?)";

            PreparedStatement pst =
                conn.prepareStatement(query);

            pst.setString(1, edukasi.getEdukasi());
           
            return pst.executeUpdate() > 0;

        } catch (Exception e) {

            System.out.println(
                "Tambah edukasi Error : "
                + e.getMessage()
            );

        }

        return false;
    }

    public ArrayList<Edukasi> getAllEdukasi() {

        ArrayList<Edukasi> list =
            new ArrayList<>();

        try {

            String query =
                "SELECT * FROM edukasi";

            PreparedStatement pst =
                conn.prepareStatement(query);

            ResultSet rs =
                pst.executeQuery();

            while(rs.next()) {

                Edukasi edukasi =
                    new Edukasi();

                edukasi.setId(
                    rs.getInt("id")
                );

                edukasi.setEdukasi(
                    rs.getString("edukasi")
                );

                list.add(edukasi);
            }

        } catch(Exception e) {

            System.out.println(
                e.getMessage()
            );

        }

        return list;
    }

    public boolean hapusEdukasi(int id) {

        try {

            String query =
                "DELETE FROM edukasi "
                + "WHERE id=?";

            PreparedStatement pst =
                conn.prepareStatement(query);

            pst.setInt(1, id);

            return pst.executeUpdate() > 0;

        } catch(Exception e) {

            System.out.println(
                e.getMessage()
            );

        }

        return false;
    }
}
