/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

/**
 *
 * @author lulutt
 */
import Koneksi.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import model.Laporan;
public class LaporanController {

    public LaporanController() {
        // Koneksi diambil ulang di setiap method agar selalu fresh.
    }

    public boolean tambahLaporan(Laporan laporan) {

        try {

            Connection conn = Connector.getConnection();
            if (conn == null) {
                return false;
            }

            String query =
                "INSERT INTO laporan "
                + "(nama,lokasi,laporan,status) "
                + "VALUES (?,?,?,?)";

            PreparedStatement pst =
                conn.prepareStatement(query);

            pst.setString(1, laporan.getNama());
            pst.setString(2, laporan.getLokasi());
            pst.setString(3, laporan.getLaporan());
            pst.setString(4, laporan.getStatus());

            return pst.executeUpdate() > 0;

       } catch (Exception e) {

    javax.swing.JOptionPane.showMessageDialog(
        null,
        "Gagal mengirim laporan:\n" + e.toString()
    );

    e.printStackTrace();

}

        return false;
    }

    public ArrayList<Laporan> getAllLaporan() {

        ArrayList<Laporan> list =
            new ArrayList<>();

        try {

            Connection conn = Connector.getConnection();
            if (conn == null) {
                return list;
            }

            String query =
                "SELECT * FROM laporan";

            PreparedStatement pst =
                conn.prepareStatement(query);

            ResultSet rs =
                pst.executeQuery(); //menyimpan seluruh data

           //looping data untuk mengambil data satu persatu
           while(rs.next()) {

                Laporan laporan =
                    new Laporan();

                laporan.setId(
                    rs.getInt("id")
                );
                //mapping

                laporan.setNama(
                    rs.getString("nama")
                );

                laporan.setLokasi(
                    rs.getString("lokasi")
                );

                laporan.setLaporan(
                    rs.getString("laporan")
                );

                laporan.setStatus(
                    rs.getString("status")
                );

               

                list.add(laporan);
            }

        } catch (Exception e) {

    javax.swing.JOptionPane.showMessageDialog(
        null,
        e.toString()
    );

    e.printStackTrace();

}

        return list;
    }

    public ArrayList<Laporan> cariLaporan(String keyword) {

        ArrayList<Laporan> list = new ArrayList<>();

        try {
            Connection conn = Connector.getConnection();
            if (conn == null) {
                return list;
            }

            String query =
                "SELECT * FROM laporan "
              + "WHERE nama LIKE ? OR lokasi LIKE ? OR laporan LIKE ? "
              + "ORDER BY id DESC";

            PreparedStatement pst = conn.prepareStatement(query);
            String like = "%" + keyword + "%";
            pst.setString(1, like);
            pst.setString(2, like);
            pst.setString(3, like);

            ResultSet rs = pst.executeQuery();

            while (rs.next()) {
                Laporan laporan = new Laporan();
                laporan.setId(rs.getInt("id"));
                laporan.setNama(rs.getString("nama"));
                laporan.setLokasi(rs.getString("lokasi"));
                laporan.setLaporan(rs.getString("laporan"));
                laporan.setStatus(rs.getString("status"));
                list.add(laporan);
            }

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, e.toString());
            e.printStackTrace();
        }

        return list;
    }

    public Laporan getLaporanById(int id) {

        try {
            Connection conn = Connector.getConnection();
            if (conn == null) {
                return null;
            }

            String query = "SELECT * FROM laporan WHERE id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, id);

            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                Laporan laporan = new Laporan();
                laporan.setId(rs.getInt("id"));
                laporan.setNama(rs.getString("nama"));
                laporan.setLokasi(rs.getString("lokasi"));
                laporan.setLaporan(rs.getString("laporan"));
                laporan.setStatus(rs.getString("status"));
                return laporan;
            }

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, e.toString());
            e.printStackTrace();
        }

        return null;
    }

    public boolean updateStatus(int id, String status) {

        try {
            Connection conn = Connector.getConnection();
            if (conn == null) {
                return false;
            }

            String query = "UPDATE laporan SET status=? WHERE id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, status);
            pst.setInt(2, id);

            return pst.executeUpdate() > 0;

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, e.toString());
            e.printStackTrace();
        }

        return false;
    }

    public boolean updateLaporan(Laporan laporan) {

        try {
            Connection conn = Connector.getConnection();
            if (conn == null) {
                return false;
            }

            String query =
                "UPDATE laporan SET nama=?, lokasi=?, laporan=?, status=? WHERE id=?";

            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, laporan.getNama());
            pst.setString(2, laporan.getLokasi());
            pst.setString(3, laporan.getLaporan());
            pst.setString(4, laporan.getStatus());
            pst.setInt(5, laporan.getId());

            return pst.executeUpdate() > 0;

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, e.toString());
            e.printStackTrace();
        }

        return false;
    }

    public boolean deleteLaporan(int id) {

        try {
            Connection conn = Connector.getConnection();
            if (conn == null) {
                return false;
            }

            String query = "DELETE FROM laporan WHERE id=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setInt(1, id);

            return pst.executeUpdate() > 0;

        } catch (Exception e) {
            javax.swing.JOptionPane.showMessageDialog(null, e.toString());
            e.printStackTrace();
        }

        return false;
    }

    public int getJumlahLaporan() {

        try {
            Connection conn = Connector.getConnection();
            if (conn == null) {
                return 0;
            }

            String query = "SELECT COUNT(*) AS jumlah FROM laporan";
            PreparedStatement pst = conn.prepareStatement(query);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return rs.getInt("jumlah");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

    public int getJumlahByStatus(String status) {

        try {
            Connection conn = Connector.getConnection();
            if (conn == null) {
                return 0;
            }

            String query = "SELECT COUNT(*) AS jumlah FROM laporan WHERE status=?";
            PreparedStatement pst = conn.prepareStatement(query);
            pst.setString(1, status);
            ResultSet rs = pst.executeQuery();

            if (rs.next()) {
                return rs.getInt("jumlah");
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return 0;
    }

}

