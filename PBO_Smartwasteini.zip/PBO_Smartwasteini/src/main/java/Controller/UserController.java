/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Controller;

import Koneksi.Connector;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

/**
 *
 * @author lulutt
 */
public class UserController {

    public UserController() {
        // Koneksi diambil ulang di setiap method agar selalu fresh
        // (tidak tersangkut pada koneksi gagal saat objek pertama dibuat).
    }

   public boolean login(String email, String password) {

    try {

        Connection conn = Connector.getConnection();
        if (conn == null) {
            return false;
        }

        String query =
            "SELECT * FROM user "
            + "WHERE email=? "
            + "AND password=?";

        PreparedStatement pst =
            conn.prepareStatement(query);

        pst.setString(1, email);
        pst.setString(2, password);

        ResultSet rs = pst.executeQuery();

        return rs.next();

    } catch (Exception e) {

        System.out.println(
            "Login Error : "
            + e.getMessage()
        );
        e.printStackTrace();

    }

    return false;
}
  public boolean login(String email) {

    try {

        Connection conn = Connector.getConnection();
        if (conn == null) {
            return false;
        }

        String query =
            "SELECT * FROM user WHERE email=?";

        PreparedStatement pst =
            conn.prepareStatement(query);

        pst.setString(1, email);

        ResultSet rs =
            pst.executeQuery();

        return rs.next();

    } catch(Exception e) {

        System.out.println(e.getMessage());
        e.printStackTrace();
    }

    return false;
}

public String getRole(String email) {

    try {

        Connection conn = Connector.getConnection();
        if (conn == null) {
            return "";
        }

        String query =
            "SELECT role FROM user WHERE email=?";

        PreparedStatement pst =
            conn.prepareStatement(query);

        pst.setString(1, email);

        ResultSet rs =
            pst.executeQuery();

        if(rs.next()) {

            return rs.getString("role");

        }

    } catch(Exception e) {

        System.out.println(
            "Get Role Error : "
            + e.getMessage()
        );
        e.printStackTrace();

    }

    return "";
}
public boolean register(
        String fullname,
        String email,
        String phone,
        String address,
        String password,
        String role) {

    try {

        Connection conn = Connector.getConnection();
        if (conn == null) {
            return false;
        }

        String sql =
            "INSERT INTO user "
            + "(fullname,email,password,role) "
            + "VALUES (?,?,?,?)";

        PreparedStatement pst =
            conn.prepareStatement(sql);

        pst.setString(1, fullname);
        pst.setString(2, email);
        pst.setString(3, password);
        pst.setString(4, role);

        return pst.executeUpdate() > 0;

    } catch(Exception e) {

        javax.swing.JOptionPane.showMessageDialog(
            null,
            e.toString()
        );

        e.printStackTrace();

    }

    return false;

}
}
