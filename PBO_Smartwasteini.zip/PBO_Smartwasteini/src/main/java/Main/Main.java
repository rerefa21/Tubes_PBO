/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Main;

/**
 *
 * @author lulutt
 */
import view.Login;

public class Main {

    public static void main(String[] args) {

        try {

            javax.swing.UIManager.setLookAndFeel(
                javax.swing.UIManager.getSystemLookAndFeelClassName()
            );

        } catch (Exception e) {

            System.out.println(e.getMessage());

        }

        java.awt.EventQueue.invokeLater(new Runnable() {

            @Override
            public void run() {

                new Login().setVisible(true);

            }

        });

    }
}