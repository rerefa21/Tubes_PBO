/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.smartwaste;

/**
 *
 * @author lulutt
 */
public class Smartwaste {

    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
