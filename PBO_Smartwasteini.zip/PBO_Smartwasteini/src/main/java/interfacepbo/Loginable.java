/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Interface.java to edit this template
 */
package interfacepbo;

/**
 *
 * @author lulutt
 */
public interface Loginable {
    boolean Login (String email, String password);
}
