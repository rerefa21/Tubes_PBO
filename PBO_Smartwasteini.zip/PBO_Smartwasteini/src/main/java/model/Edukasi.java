/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author lulutt
 */
public class Edukasi {
        private int id;
    private String edukasi;

    public Edukasi() {
    }

    public Edukasi(int id, String edukasi) {
        this.id = id;
        this.edukasi = edukasi;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getEdukasi() {
        return edukasi;
    }

    public void setEdukasi(String edukasi) {
        this.edukasi = edukasi;
    }

}  

