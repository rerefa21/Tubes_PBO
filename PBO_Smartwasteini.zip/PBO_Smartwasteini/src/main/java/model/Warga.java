/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

import interfacepbo.Loginable;

/**
 *
 * @author lulutt
 */
public class Warga extends User implements Loginable {
    public Warga() {
    }

    public Warga(int id, String fullname, String email, String password, String role) {
        super(id, fullname, email, password, role);
    }
    @Override
    public boolean Login(String email, String password) {
        return this.email.equals(email)
                && this.password.equals(password);

    }
}
