/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package model;

/**
 *
 * @author lulutt
 */
public class Laporan {
   private int id;
    private String nama;
    private String lokasi;
    private String laporan;
    private String status;
    private User user;

    public Laporan() {
    }
    public Laporan(int id, String nama, String lokasi, String laporan, String status) {
        this.id = id;
        this.nama = nama;
        this.lokasi = lokasi;
        this.laporan = laporan;
        this.status = status;
    }
    public int getId() {
        return id;
    }
    public void setId(int id) {
        this.id = id;
    }
    public String getNama() {
        return nama;
    }
    public void setNama(String nama) {
        this.nama = nama;
    }
    public String getLokasi() {
        return lokasi;
    }
    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }
    public String getLaporan() {
        return laporan;
    }
    public void setLaporan(String laporan) {
        this.laporan = laporan;
    }
    public String getStatus() {
        return status;
    }
    public void setStatus(String status) {
        this.status = status;
    }
    public User getUser() {
    return user;
    }   
public void setUser(User user) {
    this.user = user;
}
}
