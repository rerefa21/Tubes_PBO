/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Koneksi;

import java.sql.Connection;
import java.sql.DriverManager;

/**
 *
 * @author lulutt
 */
public class Connector {
   private static Connection conn;
   public static Connection getConnection() {
    try {
        Class.forName("com.mysql.cj.jdbc.Driver");

        String url =
            "jdbc:mysql://localhost:3306/tubespbo?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";

        String user = "root";
        String pass = "";

        conn = DriverManager.getConnection(
                url,
                user,
                pass
        );

        System.out.println("Koneksi Berhasil");

    } catch (Exception e) {

        System.out.println(
            "Koneksi Gagal : "
            + e.getMessage()
        );

        e.printStackTrace();

        javax.swing.JOptionPane.showMessageDialog(
                null,
                "Koneksi ke database gagal:\n" + e.getMessage()
                + "\n\nPastikan MySQL/XAMPP sudah berjalan dan database 'tubespbo' sudah dibuat.",
                "Koneksi Database Gagal",
                javax.swing.JOptionPane.ERROR_MESSAGE
        );

        conn = null;
    }

    return conn;
}
}
